<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CouponVendorTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {


        \DB::table('coupon_vendor')->delete();

  
    }
}
