<html lang="en">

<head>
    <title>{{ $title }}</title>
</head>

<body>
    {!! $content !!}
</body>

</html>
