<div class="h-80 p-5 {{ $bg ?? 'bg-white' }} border rounded shadow-lg">
    {{ $slot }}
</div>
