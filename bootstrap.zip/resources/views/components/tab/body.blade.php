<div x-show="openTab == {{ $tab ?? 0 }}" class="mt-4">
    {{ $slot ?? '' }}
</div>
