<span>
    {{  $loop->iteration + $list->firstItem() - 1  }}
</span>
