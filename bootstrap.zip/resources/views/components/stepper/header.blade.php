<div x-show="currentStep == {{ $step ?? 1 }}">
    <div class="text-lg font-bold text-gray-700 leading-tight">{{ $title ?? '' }}</div>
</div>
