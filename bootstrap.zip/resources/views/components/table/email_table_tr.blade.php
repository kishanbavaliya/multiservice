<tr>
    <td align="left"
        style="padding:0;Margin:0;line-height:19px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:15px">
        {!! $title ?? '' !!}
    </td>

    <td align="right"
        style="padding:0;Margin:0;line-height:18px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:16px; font-weight: bold;">
        {!! $content ?? '' !!}
    </td>
</tr>
