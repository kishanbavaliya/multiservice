{{ currencyFormat( $model->wallet->balance ?? 0.00 ) }}
