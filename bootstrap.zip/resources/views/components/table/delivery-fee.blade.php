{{ currencyFormat($model->delivery_fee ?? '') }}
