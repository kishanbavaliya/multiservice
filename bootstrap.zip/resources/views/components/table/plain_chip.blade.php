<div class="flex justify-start items-start">
    <p
        class="max-w-xs border-0 shadow-sm text-center py-1 px-3 text-xs  {{ $textColor ?? 'text-gray-700' }} {{ $bgColor ?? 'bg-gray-100' }} rounded-full ">
        {{ $text ?? '' }}
    </p>
</div>
