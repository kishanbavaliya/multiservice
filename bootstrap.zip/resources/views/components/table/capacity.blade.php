{{ $model->capacity ?? '' }} {{ $model->unit ?? '' }}
