<div class="{{ $textColor ?? 'text-gray-700' }} {{ $bgColor ?? '' }}">
    {!! $text ?? '' !!}
</div>
