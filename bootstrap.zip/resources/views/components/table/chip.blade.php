<div
    class="flex items-center justify-center px-2 py-1 m-1 font-medium {{ $textColor ?? 'text-gray-700' }} {{ $bgColor ?? 'bg-gray-100' }}  border border-gray-300 rounded-full ">
    <div class="flex-initial max-w-full text-xs font-normal leading-none">{{ $text ?? '' }}</div>
</div>
