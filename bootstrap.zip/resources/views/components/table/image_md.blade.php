<div>
    <a href="{{ $model->photo ?? $column->attribute }}" target="_blank">
    <img src="{{ $model->photo }}" class="object-cover w-32 h-24 overflow-hidden bg-white rounded" />
    </a>
</div>
