{{ currencyFormat($model->discount_price ?? $model->discount ?? '') }}
