<div>
    <img src="{{ $model->logo }}" class="object-cover w-12 h-8 overflow-hidden bg-white rounded" />
</div>
