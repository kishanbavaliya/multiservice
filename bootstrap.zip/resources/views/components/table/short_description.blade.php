{{ Str::limit( $model->description ?? '', 50) }}
