{{ currencyFormat($value ?? $model->price ?? $model[$column->attribute] ??  '') }}
