<div>
    <a href="{{ $model->photo ?? $column->attribute }}" target="_blank"> <img src="{{ $model->photo ?? $column->attribute }}" class="object-cover w-6 h-6 overflow-hidden bg-white rounded" />
    </a>
</div>
