<p class="break-all">{{ $value ??  $model[$column->attribute] ?? '' }}</p>
