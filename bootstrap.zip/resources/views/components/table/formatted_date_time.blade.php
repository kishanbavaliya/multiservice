<p>{{ $model->formatted_date ?? '' }}</p>
<p>{{ $model->formatted_time ?? '' }}</p>
