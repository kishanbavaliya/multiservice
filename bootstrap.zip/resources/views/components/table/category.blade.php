{{ $model->category->name }}
