<x-heroicon-o-x-circle class="w-5 h-5 text-red-500" />
