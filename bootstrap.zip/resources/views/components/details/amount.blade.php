<div class="flex justify-between">
    <p class="mb-1 text-gray-700" dir="rtl">{{ $title ?? '' }}</p>
    <x-details.p text="{{ $amount ?? 0.0 }}" />
</div>
