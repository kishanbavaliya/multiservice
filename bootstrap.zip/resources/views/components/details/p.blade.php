<p class="font-medium">{{ $text ?? '' }}{{ $slot ?? '' }}</p>
