<div>
    <x-select-xs :options='$languages ?? []' name="lan" :defer="false" />
</div>
