@extends('layouts.auth')
@section('title', __('Privacy Policy'))
@section('content')
<div class="w-10/12 mx-auto my-10">
    @include('layouts.includes.privacy')
</div>
@endsection
