<?php

return [

    'reset' => 'Your password has been reset!',

];
