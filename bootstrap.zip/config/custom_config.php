<?php

return [
    'account_remove_code' => "remv_",
];
